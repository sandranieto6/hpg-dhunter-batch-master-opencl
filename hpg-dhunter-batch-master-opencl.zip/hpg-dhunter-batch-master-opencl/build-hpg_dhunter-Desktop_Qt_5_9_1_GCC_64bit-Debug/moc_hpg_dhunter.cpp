/****************************************************************************
** Meta object code from reading C++ file 'hpg_dhunter.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../hpg-dhunter-batch-master3/src/hpg_dhunter.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'hpg_dhunter.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_HPG_Dhunter_t {
    QByteArrayData data[35];
    char stringdata0[746];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_HPG_Dhunter_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_HPG_Dhunter_t qt_meta_stringdata_HPG_Dhunter = {
    {
QT_MOC_LITERAL(0, 0, 11), // "HPG_Dhunter"
QT_MOC_LITERAL(1, 12, 20), // "on_case_file_clicked"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 35), // "on_case_files_cursorPositionC..."
QT_MOC_LITERAL(4, 70, 22), // "on_delete_case_clicked"
QT_MOC_LITERAL(5, 93, 18), // "on_up_case_clicked"
QT_MOC_LITERAL(6, 112, 20), // "on_down_case_clicked"
QT_MOC_LITERAL(7, 133, 23), // "on_control_file_clicked"
QT_MOC_LITERAL(8, 157, 38), // "on_control_files_cursorPositi..."
QT_MOC_LITERAL(9, 196, 25), // "on_delete_control_clicked"
QT_MOC_LITERAL(10, 222, 21), // "on_up_control_clicked"
QT_MOC_LITERAL(11, 244, 23), // "on_down_control_clicked"
QT_MOC_LITERAL(12, 268, 19), // "on_out_path_clicked"
QT_MOC_LITERAL(13, 288, 13), // "on_mC_clicked"
QT_MOC_LITERAL(14, 302, 14), // "on_hmC_clicked"
QT_MOC_LITERAL(15, 317, 18), // "on_forward_clicked"
QT_MOC_LITERAL(16, 336, 18), // "on_reverse_clicked"
QT_MOC_LITERAL(17, 355, 21), // "on_all_chroms_toggled"
QT_MOC_LITERAL(18, 377, 25), // "on_threshold_valueChanged"
QT_MOC_LITERAL(19, 403, 5), // "value"
QT_MOC_LITERAL(20, 409, 27), // "on_mC_cobertura_sliderMoved"
QT_MOC_LITERAL(21, 437, 28), // "on_hmC_cobertura_sliderMoved"
QT_MOC_LITERAL(22, 466, 29), // "on_dmr_dwt_level_valueChanged"
QT_MOC_LITERAL(23, 496, 24), // "on_mC_min_cov_textEdited"
QT_MOC_LITERAL(24, 521, 4), // "arg1"
QT_MOC_LITERAL(25, 526, 25), // "on_hmC_min_cov_textEdited"
QT_MOC_LITERAL(26, 552, 16), // "on_start_clicked"
QT_MOC_LITERAL(27, 569, 15), // "on_stop_clicked"
QT_MOC_LITERAL(28, 585, 13), // "fichero_leido"
QT_MOC_LITERAL(29, 599, 15), // "cromosoma_leido"
QT_MOC_LITERAL(30, 615, 21), // "refGen_worker_acabado"
QT_MOC_LITERAL(31, 637, 31), // "on_grouped_samples_stateChanged"
QT_MOC_LITERAL(32, 669, 30), // "on_single_samples_stateChanged"
QT_MOC_LITERAL(33, 700, 39), // "on_genome_reference_currentIn..."
QT_MOC_LITERAL(34, 740, 5) // "index"

    },
    "HPG_Dhunter\0on_case_file_clicked\0\0"
    "on_case_files_cursorPositionChanged\0"
    "on_delete_case_clicked\0on_up_case_clicked\0"
    "on_down_case_clicked\0on_control_file_clicked\0"
    "on_control_files_cursorPositionChanged\0"
    "on_delete_control_clicked\0"
    "on_up_control_clicked\0on_down_control_clicked\0"
    "on_out_path_clicked\0on_mC_clicked\0"
    "on_hmC_clicked\0on_forward_clicked\0"
    "on_reverse_clicked\0on_all_chroms_toggled\0"
    "on_threshold_valueChanged\0value\0"
    "on_mC_cobertura_sliderMoved\0"
    "on_hmC_cobertura_sliderMoved\0"
    "on_dmr_dwt_level_valueChanged\0"
    "on_mC_min_cov_textEdited\0arg1\0"
    "on_hmC_min_cov_textEdited\0on_start_clicked\0"
    "on_stop_clicked\0fichero_leido\0"
    "cromosoma_leido\0refGen_worker_acabado\0"
    "on_grouped_samples_stateChanged\0"
    "on_single_samples_stateChanged\0"
    "on_genome_reference_currentIndexChanged\0"
    "index"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_HPG_Dhunter[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      30,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  164,    2, 0x08 /* Private */,
       3,    0,  165,    2, 0x08 /* Private */,
       4,    0,  166,    2, 0x08 /* Private */,
       5,    0,  167,    2, 0x08 /* Private */,
       6,    0,  168,    2, 0x08 /* Private */,
       7,    0,  169,    2, 0x08 /* Private */,
       8,    0,  170,    2, 0x08 /* Private */,
       9,    0,  171,    2, 0x08 /* Private */,
      10,    0,  172,    2, 0x08 /* Private */,
      11,    0,  173,    2, 0x08 /* Private */,
      12,    0,  174,    2, 0x08 /* Private */,
      13,    0,  175,    2, 0x08 /* Private */,
      14,    0,  176,    2, 0x08 /* Private */,
      15,    0,  177,    2, 0x08 /* Private */,
      16,    0,  178,    2, 0x08 /* Private */,
      17,    1,  179,    2, 0x08 /* Private */,
      18,    1,  182,    2, 0x08 /* Private */,
      20,    1,  185,    2, 0x08 /* Private */,
      21,    1,  188,    2, 0x08 /* Private */,
      22,    1,  191,    2, 0x08 /* Private */,
      23,    1,  194,    2, 0x08 /* Private */,
      25,    1,  197,    2, 0x08 /* Private */,
      26,    0,  200,    2, 0x08 /* Private */,
      27,    0,  201,    2, 0x08 /* Private */,
      28,    4,  202,    2, 0x08 /* Private */,
      29,    1,  211,    2, 0x08 /* Private */,
      30,    1,  214,    2, 0x08 /* Private */,
      31,    1,  217,    2, 0x08 /* Private */,
      32,    1,  220,    2, 0x08 /* Private */,
      33,    1,  223,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Int,   19,
    QMetaType::Void, QMetaType::Int,   19,
    QMetaType::Void, QMetaType::Int,   19,
    QMetaType::Void, QMetaType::Int,   19,
    QMetaType::Void, QMetaType::QString,   24,
    QMetaType::Void, QMetaType::QString,   24,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,    2,    2,    2,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::ULong,    2,
    QMetaType::Void, QMetaType::Int,   24,
    QMetaType::Void, QMetaType::Int,   24,
    QMetaType::Void, QMetaType::Int,   34,

       0        // eod
};

void HPG_Dhunter::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        HPG_Dhunter *_t = static_cast<HPG_Dhunter *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_case_file_clicked(); break;
        case 1: _t->on_case_files_cursorPositionChanged(); break;
        case 2: _t->on_delete_case_clicked(); break;
        case 3: _t->on_up_case_clicked(); break;
        case 4: _t->on_down_case_clicked(); break;
        case 5: _t->on_control_file_clicked(); break;
        case 6: _t->on_control_files_cursorPositionChanged(); break;
        case 7: _t->on_delete_control_clicked(); break;
        case 8: _t->on_up_control_clicked(); break;
        case 9: _t->on_down_control_clicked(); break;
        case 10: _t->on_out_path_clicked(); break;
        case 11: _t->on_mC_clicked(); break;
        case 12: _t->on_hmC_clicked(); break;
        case 13: _t->on_forward_clicked(); break;
        case 14: _t->on_reverse_clicked(); break;
        case 15: _t->on_all_chroms_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 16: _t->on_threshold_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->on_mC_cobertura_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->on_hmC_cobertura_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->on_dmr_dwt_level_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->on_mC_min_cov_textEdited((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 21: _t->on_hmC_min_cov_textEdited((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 22: _t->on_start_clicked(); break;
        case 23: _t->on_stop_clicked(); break;
        case 24: _t->fichero_leido((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 25: _t->cromosoma_leido((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 26: _t->refGen_worker_acabado((*reinterpret_cast< ulong(*)>(_a[1]))); break;
        case 27: _t->on_grouped_samples_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 28: _t->on_single_samples_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 29: _t->on_genome_reference_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject HPG_Dhunter::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_HPG_Dhunter.data,
      qt_meta_data_HPG_Dhunter,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *HPG_Dhunter::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *HPG_Dhunter::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_HPG_Dhunter.stringdata0))
        return static_cast<void*>(const_cast< HPG_Dhunter*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int HPG_Dhunter::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 30)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 30;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 30)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 30;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
